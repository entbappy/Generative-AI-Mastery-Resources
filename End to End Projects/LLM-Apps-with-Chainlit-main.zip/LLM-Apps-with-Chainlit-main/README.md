# LLM-Apps-with-Chainlit

# Chainlit demo

Chainlit is like Streamlit for LLM app development :)

To Know more about Chainlit, refer the official docs - https://docs.chainlit.io/overview



---


### CMD:

```bash
chainlit init
```

```bash
chainlit run app.py
```